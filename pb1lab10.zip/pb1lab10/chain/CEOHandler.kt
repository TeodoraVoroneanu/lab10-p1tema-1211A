package chain

//import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class CEOHandler(var var1: Handler? = null, var var2: Handler? = null, var var3: Handler? = null): Handler {
    override suspend fun handleRequest( messageToBeProcessed: String) = coroutineScope {
        var sent = messageToBeProcessed.split(":")
        var priorityy = sent.elementAt(0)
        var messageee = sent.elementAt(1)


        if (priorityy == "1") {
            var job=launch{print(" CEO successfully did the message " + messageee)}
            job.join()
        }
        else
        {   var job=launch {
            if (var2 != null) {
                print(" se trimite mesaj catre CEO superior  " +messageee)
                var2?.handleRequest("1:" + messageee)
            } else {
                print("De la CEO se trimite mesaj la Executive" + messageee)
                var3?.handleRequest(messageToBeProcessed)
            }
        }
            job.join()
        }
    }
}