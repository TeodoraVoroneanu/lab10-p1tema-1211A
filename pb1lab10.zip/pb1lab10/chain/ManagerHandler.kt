package chain

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class ManagerHandler(var var1: Handler? = null, var var2: Handler? = null, var var3: Handler? = null): Handler {
    override suspend fun handleRequest(messageToBeProcessed: String) = coroutineScope {
        var sent=messageToBeProcessed.split(":")
        var priorityy=sent.elementAt(0)
        var messageee=sent.elementAt(1)
        if(priorityy=="3") {
            var job=launch{
            if (var1 == null) {
                print(" Managgerul  prelucreaza mesajul dupa care il trimite  " + messageee)
                var2?.handleRequest(messageToBeProcessed)
            } else {
                print("Managerul trimite mesajul la Executive  " + messageee)
                var1?.handleRequest(messageToBeProcessed)
            }
                }
            job.join()
        }
        else
        {
            var job=launch {
                if (var1 != null) {
                    print("Managerul trimite mesajul la Executive  " + messageeej)
                    var1?.handleRequest(messageToBeProcessed)
                } else {
                    print(" Manager trimite mesajul la HappyWorker" + messageee)
                    var3?.handleRequest(messageToBeProcessed)
                }
            }
            job.join()
        }
    }
}