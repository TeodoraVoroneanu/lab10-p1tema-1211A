package chain

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class ExecutiveHandler(var var1: Handler? = null, var var2: Handler? = null, var var3: Handler? = null): Handler {
    override suspend fun handleRequest(messageToBeProcessed: String) = coroutineScope {
        var sent=messageToBeProcessed.split(":")
        var priorityy=sent.elementAt(0)
        var messageee=sent.elementAt(1)

        if(priorityy=="2") {
            var job=launch {
                if (var1== null) {
                print("Executive preia mesajul si il trimite dupa ce il prelucreaza/mesajul trimis mai departe e  " + messageee)
                var2?.handleRequest(messageToBeProcessed)
                }
                else {
                print("Executive trimite la Ceo  mesajul " + messageee)
                var1?.handleRequest(messageToBeProcessed)

                }
            }
            job.join()

        }
        else
        {
            var job=launch {
                if(var1!=null) {
                    print("Executive trimite la Ceo  mesajul " + messageee)
                    var1?.handleRequest(messageToBeProcessed)
                }
                else {
                    print("Executive trimite mesajul la manager/mesajul trimis e  " + messageee)
                    var3?.handleRequest(messageToBeProcessed)
                }
            }
            job.join()
        }
    }
}