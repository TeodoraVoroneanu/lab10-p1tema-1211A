package chain

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class HappyWorkerHandler(var var1: Handler? = null, var var2: Handler? = null, var var3: Handler? = null): Handler {
    override suspend fun handleRequest(messageToBeProcessed: String) = coroutineScope {
        var sent=messageToBeProcessed.split(":")
        var priorityy=sent.elementAt(0)
        var messageee=sent.elementAt(1)
        if(priorityy=="4") {
            var job=launch {
                if (var1 == null) {
                    print("Happyworker prelucreaza mesajul apoi il trimite jos/  " + messageee)
                    var2?.handleRequest(messageToBeProcessed)
                } else {
                    print(" HappyWorker trimite mesajul la manager mesajul " + messageee)
                    var1?.handleRequest(messageToBeProcessed)
                }
            }
            job.join()
        }

        else
        {
            var job=launch {
            throw Exception("nu se poate prelucra")
            }
            job.join()
        }
    }
}