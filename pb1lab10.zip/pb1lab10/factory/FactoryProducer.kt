package factory

class FactoryProducer {
    fun getFactory(choice: String): AbstractFactory {
        TODO()
    }
}